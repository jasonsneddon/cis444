/* Jason Sneddon - snedd001
 * CIS 444 - Term Project
 * Main_Page.js
 *
 */
